package day02;

public class HomeWork02 {
    public static void main(String[] args) {
        //int 数据类型（四个字节）

        int a;
        int b,c,d;
        int e=20;
        int f;
        f=260;
        int g=5;
        int h=g+100;
        System.out.println(h);
        System.out.println("h");
        g=g+10;
        System.out.println(g);
        int a1,a_5$,_3c,$_b;
        int aa=5;
        int age;
        int score,myScore,myJavaScore;
        int a2=26;
        int a3=10000000;
        System.out.println(5/2);
        System.out.println(2/3);
        System.out.println(5%9);
        int a4=2147483647;
        a4++;
        System.out.println(a4);

        //long数据行（八个字节）
        long b1=323L;
        long b2=10000000000000000L;
        long b3=1000000000*2*10L;
        long b4=1000000000;
        System.out.println(b3);
        long b5=1000000000*3*10L;
        System.out.println(b5);
        long b6=1000000000L*3151/10;
        System.out.println(b6);

        //double数据类型（八个字节）

        double c1=3.1456926;
        float c2=3.14158566f;
        double c3=3.3,c4=3.1;
        System.out.println(c3-c4);

        //boolean数据类型（一个字节）
        boolean d1=true;
        boolean d2=false;


        //char数据类型（两个字节）

        char e1='女';
        char e2='f';
        char e3='*';
        char e4=' ';
        char e5='/';
        char e6='\\';
        System.out.println(e6);
        System.out.println(e4);

        //数据类型转换（自动转换）和（强制转换）

        int f1=5;
        long f2=f1;
        int f3=(int)f2;
        System.out.println(f3);
        long f4=6;
        double f5=5;
        long f6=10000000000000L;
        int f7=(int)f6;
        System.out.println(f7);
        double f8=25.85265;
        int f9=(int)f8;
        System.out.println(f9);

        //基本数据类型的转换：两点规则
        byte g1=53;
        byte g2=-10;
        byte g3=(byte) (g1+g2);
        System.out.println(g3);
        System.out.println(2+3);
        System.out.println('a'+'8'+'A');
        System.out.println('2'+'2');
        System.out.println('3'+3);
        System.out.println('3');






    }
}
