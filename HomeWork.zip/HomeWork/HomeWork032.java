package day03;

public class HomeWork032 {
    public static void main(String[] args) {
        // 1运算符练习
        System.out.println(5%2);
        System.out.println(8%2);
        System.out.println(2%8);

        int a=10 ,b=15;
        a++;
        ++b;
        System.out.println(a);
        System.out.println(b);
        int a1=12,b1=16;
        a1--;
        --b1;
        System.out.println(a1);
        System.out.println(b1);
        int a2=5,b2=65;



    }
}
